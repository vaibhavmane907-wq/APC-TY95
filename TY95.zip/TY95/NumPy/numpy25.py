import numpy as np

arr = np.random.randint(1, 101, size=(3, 4, 5))
flat = arr.flatten()
average = np.mean(flat)

print("Original array:")
print(arr)
print("Elements greater than 50:", flat[flat > 50])
print("Even numbers:", flat[flat % 2 == 0])
print("Elements less than average:", flat[flat < average])
