import numpy as np

marks = np.array([78, 85, 67, 92, 74, 88, 95, 61, 80, 73])

print("Highest marks:", np.max(marks))
print("Lowest marks:", np.min(marks))
print("Average marks:", np.mean(marks))
print("Median:", np.median(marks))
print("Standard deviation:", np.std(marks))
