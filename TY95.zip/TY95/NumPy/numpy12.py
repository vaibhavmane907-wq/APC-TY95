import numpy as np

arr = np.array([10, 25, 51, 70, 35, 80, 45, 60, 20, 90])

arr[arr > 50] = 0

print("Updated array:", arr)
