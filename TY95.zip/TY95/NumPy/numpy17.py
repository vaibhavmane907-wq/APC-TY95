import numpy as np

marks = np.array([65, 72, 81, 90, 55, 76, 88, 69, 95, 84,
                  73, 61, 79, 92, 58, 87, 70, 83, 77, 66])

average = np.mean(marks)

print("Class average:", average)
print("Students scoring above average:", marks[marks > average])
