import numpy as np

arr = np.array([1, 2, 3, 2, 4, 5, 1, 6, 3, 7, 5])

print("Unique elements:", np.unique(arr))
