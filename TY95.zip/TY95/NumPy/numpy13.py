import numpy as np

arr = np.array([45, 12, 78, 3, 56, 23, 89, 10])

print("Ascending:", np.sort(arr))
print("Descending:", np.sort(arr)[::-1])
