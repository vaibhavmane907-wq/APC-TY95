import numpy as np

arr = np.array([12, 25, 7, 44, 18, 31, 9, 50, 22, 15])

print("Maximum:", np.max(arr))
print("Minimum:", np.min(arr))
print("Sum:", np.sum(arr))
print("Average:", np.mean(arr))
